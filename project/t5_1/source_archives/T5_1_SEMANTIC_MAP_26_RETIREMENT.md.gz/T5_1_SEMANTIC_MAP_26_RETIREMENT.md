# T5.1 — Semantic reconciliation map 26–34

Prepared by ChatGPT from the canonical traceability audit and the current engine snippets already retrieved from `capitanps02/Juego-Multihistoria`.

## Purpose

T5.1 is not an ID-renaming exercise. The current engine often preserves the correct principal-event count while shifting scene identity, seed origin, age, and semantics. This document organizes the remaining work by causal dependency so Codex can implement it safely.

## Execution order

1. PR #3 — Batch 01, ages 20–23.
2. PR #7 — Batch 02B, age 26 + seed chronology.
3. Rebase/refresh PR #5 — Batch 02A, exact-title repairs (`27_STAR`, `27_AWARD`, `28_RICH`).
4. Batch 02C — remaining missing age-27 canonical scenes + seed origins.
5. Batch 02D — remaining missing age-28 canonical scenes.
6. Batch 02E — remaining missing age-29 canonical scenes.
7. Batch 03A — missing age-30 canonical scenes.
8. Batch 03B — missing age 31–33 canonical scenes.
9. Only then continue to 34+ / retirement identity repair.

Do not run overlapping batches in parallel when they mutate `src/content/events/26_30/principal-events.ts`, `src/content/events/30_34/principal-events.ts`, `src/catalog/seeds.ts`, save migrations, or the T5.1 auditor.

---

# Improvement required in PR #7 (Batch 02B)

The age-26 repair should preserve principal count by treating several technical events as displaced adaptations rather than simply adding nine new scenes.

Canonical age-26 seeds / scenes already established:

- `EVT_26_BRIDGE_001` → creates `SEED_PEAK_IDENTITY`.
- `EVT_26_EUR_001` → creates `SEED_BIG_GAME_BENCH`.
- `EVT_26_MATCH_001` → creates `SEED_RECORD_CHASE`.
- `EVT_26_CAP_001` → creates `SEED_LOCKER_ENDORSEMENT`.
- `EVT_26_MED_001` → creates `SEED_PEAK_LOAD`.
- `EVT_26_DOC_001` → creates `SEED_DOCUMENTARY_ACCESS`.
- `EVT_26_RIV_001` → creates/intensifies `SEED_PUBLIC_RIVALRY` with `SEED_ADRIAN_MIRROR` history.
- `EVT_26_TEAM_002` → creates `SEED_MENTOR_ADVICE`.
- `EVT_26_NAT_002` → creates `SEED_NATIONAL_ROLE`.
- `EVT_26_FINAL_001` → consumes `SEED_BIG_GAME_BENCH` and creates `SEED_FINAL_BENCH`.

Four age-27 IDs that already exist canonically but currently write the wrong causal memory must be semantically repaired, not merely have their seed removed:

- `EVT_27_LOCK_001`: canonical scene is the manager/locker crisis and should create `SEED_MANAGER_POWER`, while `SEED_LOCKER_ENDORSEMENT` is prior memory.
- `EVT_27_BODY_001`: canonical scene is vacation vs extra training; should use/intensify self-optimization and prior `SEED_PEAK_LOAD`.
- `EVT_27_PRS_001`: canonical scene is home fans whistling; should create `SEED_FAN_FRACTURE`, not documentary access.
- `EVT_27_NAT_001`: canonical scene is national-team captaincy; should create `SEED_NATIONAL_CAPTAINCY`, not national role.

Likely displaced technical events to retire/migrate as part of the same causal repair include the technical sources of those later seeds (for example the later manager/fan/national-capitancy adaptations). Verify exact source references on the current branch before deletion; preserve historical facts and active seeds in saves without setting a new canonical `SEEN_*` flag retroactively.

---

# Batch 02C — remaining age-27 missing scenes

Seven canonical IDs remain after PR #5's `STAR/AWARD` work.

## EVT_27_CON_001 — La cláusula que sí puede pagarse

- Gate: high contract power.
- Canon choices: accept realistic clause; lower clause for lower salary; no clause and negotiate; time-limited activation window.
- Memory: existing `SEED_CONTRACT_CEILING`.
- Rule: do not redefine its origin unless the canonical seed catalog says so; this scene is a later use/intensification, not marked as a new seed.

## EVT_27_IMG_001 — Tu nombre sin tu club

- Gate: global image / media power.
- Canon choices: strong independent brand; coordinate with club; restrict campaigns to rest windows; reject international expansion.
- Creates `SEED_PERSONAL_BRAND_INDEPENDENCE`; reads `SEED_IMAGE_RIGHTS`.
- Current engine seed metadata places this seed at `EVT_28_IMG_001`, age 28+. Move origin to canonical age 27 and migrate/retire the displaced technical event after semantic comparison.

## EVT_27_HOME_001 — ¿Comprar una parte de casa?

- Gate: home institution + wealth.
- Choices: invest; donate without ownership; wait until retirement; independent vehicle/no public office.
- Creates `SEED_HOME_OWNERSHIP`; reads `SEED_HOME_INSTITUTION`.
- Current engine seed metadata places `HOME_OWNERSHIP` at `EVT_28_HOME_001`, age 28+. Move to 27.

## EVT_27_EUR_001 — La semifinal que exige desaparecer

- Gate: maximum-stage match + high attacking role.
- Choices: fully accept sacrifice; ask transition freedom; question role; comply while preventing agent criticism.
- Creates `SEED_ELITE_SACRIFICE`; reads `SEED_TACTICAL_SACRIFICE`.
- Current engine seed metadata places `ELITE_SACRIFICE` at `EVT_29_EUR_001`, age 29–36. Move lower bound and origin to canonical age 27; keep later consumers working.

## EVT_27_MATCH_001 — El récord no se celebra

- Gate: `RECORD_CHASE` resolved + negative team result.
- Choices: publish campaign; delay; short team-focused message; cancel campaign.
- Creates `SEED_RECORD_PUBLIC_TONE`; reads `SEED_RECORD_CHASE`.
- Current engine origin is technical `EVT_29_REC_001`, age 29+. Move to canonical age 27.
- Dependency: PR #7 must first make `SEED_RECORD_CHASE` available from age 26.

## EVT_27_TEAM_001 — Tu protegido juega por ti

- Gate: young successor + plausible absence.
- Choices: congratulate/help; professional but compete; ask to play together; press to return immediately.
- Creates **new** `SEED_SUCCESSOR_PEAK`; reads `SEED_YOUNG_SUCCESSOR`.
- `SEED_SUCCESSOR_PEAK` was not found in the currently loaded `SEED_CATALOG_26_30` snapshot. Codex must verify the full catalog; if still absent, add a canonical definition with origin `EVT_27_TEAM_001` and an age window beginning at 27.

## EVT_27_AGT_002 — Tu agente negocia dos futuros

- Gate: relevant contract + high agent power.
- Choices: allow both talks; choose one; take direct control of one; change agent mid-process.
- Creates **new** `SEED_PARALLEL_NEGOTIATION`; reads `SEED_AGENT_CONFLICT_PEAK`.
- `SEED_PARALLEL_NEGOTIATION` was not found in the loaded 26–30 seed catalog snapshot. Verify full catalog and add canonically if absent.
- Critical downstream consumer: `EVT_32_BOSMAN_001` explicitly uses `SEED_PARALLEL_NEGOTIATION` five years later.

### Two literal age-27 events that should be repaired in or before Batch 02C

`EVT_27_MONEY_001` canonically creates `SEED_WEALTH_STRUCTURE` from the scene “Tu patrimonio ya es una empresa”. The current seed catalog instead originates `SEED_WEALTH_STRUCTURE` at technical `EVT_28_MONEY_001`. Move origin to 27 and retire/migrate the displaced technical scene after comparison.

`EVT_27_TACT_001` canonically creates `SEED_POSITIONAL_REINVENTION` from “Cambiar para seguir arriba”. The current seed catalog instead originates it at technical `EVT_28_TACT_001`. Move origin to 27.

These two repairs are important because age-28/31 scenes consume those memories.

---

# Batch 02D — remaining age-28 missing scenes

## EVT_28_MEDIA_001 — El documental se estrena cuando ya eres otro

- Gate: active documentary access.
- Creates **new** `SEED_DOCUMENTARY_FALLOUT`; reads `SEED_DOCUMENTARY_ACCESS`.
- New seed not found in the loaded 26–30 seed catalog snapshot; verify/add.

## EVT_28_FORM_001 — Tres meses normales

- Gate: previously high peak status + merely average run.
- Creates `SEED_FIRST_PEAK_DIP`; reads `SEED_SELF_OPTIMIZATION`.
- Current engine catalog originates `FIRST_PEAK_DIP` at technical `EVT_29_FORM_001`, age 29+. Move origin/lower age bound to canonical age 28.

## EVT_28_STAR_001 — El chico ya no es promesa

- Gate: `SUCCESSOR_PEAK`.
- Creates **new** `SEED_SUCCESSION_DECISION`; reads `SEED_POSITIONAL_REINVENTION`.
- New seed not found in loaded catalog snapshot; verify/add.
- Dependency: Batch 02C must first create `SEED_SUCCESSOR_PEAK` and move `POSITIONAL_REINVENTION` to canonical age 27.

## EVT_28_MED_001 — No puedes jugar sesenta partidos

- Gate: low recovery margin + dense calendar.
- Creates **new** `SEED_LOAD_CHOICE_29`; reads `SEED_INTERNATIONAL_LOAD`.
- New seed not found in loaded catalog snapshot; verify/add.

## EVT_28_CLUB_001 — El presidente quiere tu apoyo

- Gate: high institutional power + club crisis.
- Creates **new** `SEED_PUBLIC_MANAGER_BACKING`; reads `SEED_MANAGER_POWER`.
- New seed not found in loaded catalog snapshot; verify/add.
- Dependency: PR #7 must establish the canonical manager-power chronology before this event is implemented.

PR #5 separately owns `EVT_28_RICH_001`.

---

# Batch 02E — remaining age-29 missing scenes

## EVT_29_TACT_001 — Reinventarte de verdad

- Gate: age 29 + role adaptability.
- Creates **new** `SEED_MATURE_REINVENTION`; reads `SEED_POSITIONAL_REINVENTION`.
- Seed not found in loaded 26–30 catalog snapshot; verify/add.

## EVT_29_NAT_002 — ¿Seguir con la selección a cualquier precio?

- Gate: medium/high national standing + load/age.
- Creates **new** `SEED_NATIONAL_AVAILABILITY_30`; reads `SEED_INTERNATIONAL_LOAD`.
- Seed not found in loaded 26–30 catalog snapshot; verify/add.

At the end of Batch 02E, run a semantic audit not only of unresolved IDs but also of all seed `originEvents` in `SEED_CATALOG_26_30` against the canonical `Memoria / semillas` fields. Several literal-ID events have already proven to carry shifted seed responsibilities.

---

# Batch 03A — missing canonical scenes at age 30

Ten unresolved canonical IDs:

1. `EVT_30_BRIDGE_001` — La palabra veterano
   - new `SEED_VETERAN_LABEL`; reads `SEED_AGE30_PRIORITY`.
   - only exact-title candidate in phase: technical `EVT_30_IDN_001`; do not alias without semantic comparison.
2. `EVT_30_STATUS_001` — El dorsal
   - new `SEED_DORSAL_SUCCESSION`; reads `SEED_SUCCESSOR_PEAK`.
3. `EVT_30_EUR_001` — Semifinal, minuto cero
   - new `SEED_BIG_GAME_ROTATION_30`; reads `SEED_BIG_GAME_BENCH`.
4. `EVT_30_CCH_001` — Te enteras por la pizarra
   - new `SEED_ROLE_COMMUNICATION`; reads `SEED_MANAGER_POWER`.
5. `EVT_30_RECORD_001` — Partido 500
   - new `SEED_MILESTONE_CHASE_500`; reads `SEED_RECORD_CHASE`.
6. `EVT_30_PAIN_001` — Duele, pero la imagen está limpia
   - new `SEED_PAIN_WITHOUT_SCAN`; reads `SEED_MEDICAL_AUTHORITY`.
7. `EVT_30_NANO_001` — Nano necesita una llamada
   - new `SEED_OLD_NETWORK_FAVOR`; reads `SEED_NANO_SHADOW`.
8. `EVT_30_PRS_001` — El ultimátum que nunca diste
   - new `SEED_FALSE_ULTIMATUM`.
9. `EVT_30_NAT_002` — La selección gana sin ti
   - new `SEED_NATIONAL_ABSENCE`; reads `SEED_NATIONAL_PHASEDOWN`.
10. `EVT_30_JAN_001` — Enero: especialista de lujo
   - new `SEED_SPECIALIST_BIGCLUB`; reads `SEED_SHADOW_ESCAPE`.

The canonical dependencies prove this batch must follow the 26–29 seed repairs.

---

# Batch 03B — missing canonical scenes ages 31–33

## Age 31

- `EVT_31_FAM_001` — No quiero otra mudanza
  - new `SEED_RELOCATION_LIMIT`; reads `SEED_FAMILY_ANCHOR`.
- `EVT_31_ROLE_001` — Tres goles y al banquillo
  - new `SEED_FORM_VS_PLAN`; reads `SEED_MATCH_SELECTIVITY`.
- `EVT_31_SQUAD_001` — Dos fichajes de 22
  - new `SEED_SQUAD_YOUTH_WAVE`; reads `SEED_SUCCESSION_DECISION`.
- `EVT_31_BIZ_001` — El problema es de tu socio
  - new `SEED_BUSINESS_REPUTATION_SHOCK`; reads `SEED_WEALTH_STRUCTURE` and personal-brand context.

## Age 32

- `EVT_32_RICH_001` — La oferta que paga el resto de tu vida
  - new `SEED_LATE_RICH_OFFER`; reads `SEED_WEALTHY_PEAK_EXIT`.
- `EVT_32_ELITE_001` — Doceavo hombre de un candidato
  - new `SEED_LATE_CONTENDER_BENCH`; reads `SEED_SPECIALIST_BIGCLUB`.
- `EVT_32_IMPACT_001` — Peores números, mejor equipo
  - new `SEED_LOW_STATS_HIGH_IMPACT`; reads `SEED_ROLE_REINVENTION_32`.
- `EVT_32_SUCCESSOR_001` — Tres semanas y aparece otro
  - new `SEED_REPLACEMENT_BREAKOUT`; reads `SEED_SUCCESSION_DECISION`.
- `EVT_32_LOAD_001` — No viajes
  - new `SEED_TRAVEL_LOAD`; reads `SEED_MATCH_SELECTIVITY`.
- `EVT_32_BOSMAN_001` — Enero: puedes firmar gratis
  - new `SEED_BOSMAN_33`; reads `SEED_PARALLEL_NEGOTIATION`.

## Age 33

- `EVT_33_RECORD_001` — El récord está a seis partidos
  - new `SEED_RECORD_VS_BODY`; reads `SEED_RECORD_PUBLIC_TONE`.
- `EVT_33_FIN_001` — Cumples 34
  - creates/uses `SEED_AGE34_PRIORITY` and new `SEED_RETIREMENT_DISTANCE_PROFILE`.
  - must be treated as a phase-transition/hard-deadline responsibility, not an ordinary weighted event.

---

# Required long-range regression tests

These should be added as explicit scenario tests, not inferred from aggregate QA alone.

1. **Big-game bench chain**
   `EVT_26_EUR_001` → `SEED_BIG_GAME_BENCH` → `EVT_26_FINAL_001` → `SEED_FINAL_BENCH` → later veteran big-game rotation.

2. **Record chain**
   `EVT_26_MATCH_001` → `SEED_RECORD_CHASE` → `EVT_27_MATCH_001` → `SEED_RECORD_PUBLIC_TONE` → `EVT_33_RECORD_001`.

3. **Successor chain**
   `EVT_26_TEAM_001` / young-successor context → `EVT_27_TEAM_001` → `SEED_SUCCESSOR_PEAK` → `EVT_28_STAR_001` → `SEED_SUCCESSION_DECISION` → `EVT_31_SQUAD_001` / `EVT_32_SUCCESSOR_001`.

4. **Agent/Bosman chain**
   `EVT_27_AGT_001` / `SEED_AGENT_CONFLICT_PEAK` → `EVT_27_AGT_002` → `SEED_PARALLEL_NEGOTIATION` → `EVT_32_BOSMAN_001`.

5. **Manager-power chain**
   canonical age-26 locker/captaincy memories → canonical `EVT_27_LOCK_001` → `SEED_MANAGER_POWER` → `EVT_28_CLUB_001` → later role communication at 30.

6. **Reinvention chain**
   `EVT_27_TACT_001` → `SEED_POSITIONAL_REINVENTION` → `EVT_28_STAR_001` / `EVT_29_TACT_001` → mature role/impact scenes at 32.

7. **Wealth / reputation chain**
   `EVT_27_MONEY_001` → `SEED_WEALTH_STRUCTURE` → `EVT_27_HOME_001` / later business exposure → `EVT_31_BIZ_001`.

8. **Documentary chain**
   `EVT_26_DOC_001` → `SEED_DOCUMENTARY_ACCESS` → `EVT_28_MEDIA_001` → `SEED_DOCUMENTARY_FALLOUT`.

9. **National-load chain**
   age-26/27 national-role history + `SEED_INTERNATIONAL_LOAD` → `EVT_28_MED_001` and `EVT_29_NAT_002` → veteran national phasedown/absence at 30+.

10. **Save compatibility**
    Old technical event history remains historical truth. Migration may preserve active seed state where semantically justified, but must not rewrite an old technical `SEEN_*` flag into a canonical event that the player never actually saw.

---

# Auditor improvement recommended

T5.1 should eventually have two lanes:

- **Identity reconciliation:** the currently unresolved canonical IDs.
- **Semantic/causal verification:** literal-ID matches whose title/ID exist but whose trigger, choices, body, seed origin, or downstream memory differ from the canonical source.

The current evidence already proves that literal ID equality is not enough: multiple literal-ID age-27 scenes currently write memories that belong to earlier or later canonical scenes.

A future audit should compare at minimum:

- canonical ID;
- phase/age window;
- title;
- trigger/gates;
- visible and uncertain information;
- choice labels/count;
- seed reads/writes/origins;
- NPC references;
- hard-deadline/transition responsibility;
- `canonStatus`.

`verified` must not be allowed merely because a technical adaptation shares a title or concept.


---

# Part II — Canonical semantic map 34+ → retirement → epilogue

## Scope and inventory

The canonical reconciliation audit exposes **33 late-career canonical IDs in phase `34_plus` that do not currently have literal canonical identity in the engine**:

- age 34: 11
- age 35: 10
- age 36: 5
- age 37: 3
- age 38: 2
- retirement terminal identity repairs: 2 (`EVT_RET_FAM_001`, `EVT_RET_LASTMATCH_001`)

In addition, the four literal terminal IDs that already exist (`EVT_RET_BODY_001`, `EVT_RET_HIGH_001`, `EVT_RET_LOW_001`, `EVT_RET_ANNOUNCE_001`) still require semantic verification. Literal ID equality is not proof that their triggers, choices, seeds or state transitions match canon.

## Proposed implementation batches

### T5.1 Batch 04A — age 34 foundations

Canonical missing IDs:

1. `EVT_34_BRIDGE_001` — La reunión sin horizonte
2. `EVT_34_PAY_001` — La cifra que ya no te pagan
3. `EVT_34_NT_001` — Última ventana de selección
4. `EVT_34_AGT_001` — El agente dice que esperes
5. `EVT_34_LOAD_001` — El plan de 28 partidos
6. `EVT_34_DORSAL_001` — Tu dorsal en la tienda
7. `EVT_34_MENTOR_001` — El joven te pide tus vídeos
8. `EVT_34_MATCH_001` — Un gol que rompe el plan
9. `EVT_34_NT_002` — Te dejan fuera de una convocatoria
10. `EVT_34_FAN_001` — La grada pide que empieces
11. `EVT_34_TRAVEL_001` — El viaje que no haces

Canonical causal responsibilities:

| Event | Creates/intensifies | Reads / depends on |
|---|---|---|
| `EVT_34_BRIDGE_001` | `SEED_AGE34_REALITY` | `SEED_AGE34_PRIORITY` |
| `EVT_34_PAY_001` | `SEED_VETERAN_PAYCUT` | `SEED_PUBLIC_CONTRACT` |
| `EVT_34_NT_001` | `SEED_FINAL_NT_POSTURE` | `SEED_NATIONAL_PHASEDOWN` |
| `EVT_34_AGT_001` | `SEED_LAST_AGENT_GAMBLE` | `SEED_AGENT_OMISSION` |
| `EVT_34_LOAD_001` | `SEED_28_MATCH_PLAN` | `SEED_MATCH_SELECTIVITY` |
| `EVT_34_DORSAL_001` | `SEED_FINAL_DORSAL` | `SEED_DORSAL_SUCCESSION` |
| `EVT_34_MENTOR_001` | `SEED_SUCCESSOR_ALLIANCE` | `SEED_FORMAL_MENTOR` |
| `EVT_34_MATCH_001` | `SEED_LAST_HERO_MOMENT` | `SEED_FORM_VS_PLAN` |
| `EVT_34_NT_002` | `SEED_NT_FIRST_OMISSION_LATE` | `SEED_FINAL_NT_POSTURE` |
| `EVT_34_FAN_001` | `SEED_FAREWELL_CROWD_POWER` | `SEED_FAN_LEGACY_BUFFER` |
| `EVT_34_TRAVEL_001` | `SEED_TEAM_WINS_WITHOUT_YOU` | `SEED_TRAVEL_LOAD` |

Important: age 34 must not automatically mean retirement pressure. These scenes update leverage, role acceptance, selection posture, body-management context, succession and public/fan power. Their combined consequences may alter retirement distance, but each can also support a longer career.

### T5.1 Batch 04B — age 35: prolong, reposition or prepare

Canonical missing IDs:

1. `EVT_35_CON_001` — Contrato por objetivos físicos
2. `EVT_35_FAREWELL_001` — El club ofrece homenaje... si te vas
3. `EVT_35_DUAL_001` — Te ofrecen ser jugador y enlace
4. `EVT_35_AGT_001` — Sin agente por primera vez
5. `EVT_35_TACT_001` — El nuevo rol funciona demasiado bien
6. `EVT_35_BENCH_001` — Un mes sin jugar y sigues entrenando
7. `EVT_35_RECORD_001` — El canterano rompe tu récord
8. `EVT_35_NT_001` — Te llaman por una emergencia internacional
9. `EVT_35_JAN_001` — Una oferta en enero
10. `EVT_35_IMG_001` — Te ofrecen un último gran patrocinio

Causal map:

| Event | Creates/intensifies | Reads / depends on |
|---|---|---|
| `EVT_35_CON_001` | `SEED_AVAILABILITY_CONTRACT` | `SEED_CONTRACT_CEILING` |
| `EVT_35_FAREWELL_001` | `SEED_FAREWELL_AS_LEVERAGE` | `SEED_PUBLIC_MYTH_FINAL` |
| `EVT_35_DUAL_001` | `SEED_PLAYER_LIAISON_ROLE` | `SEED_FORMAL_MENTOR` |
| `EVT_35_AGT_001` | `SEED_FINAL_AGENT_STRUCTURE` | `SEED_SELF_REPRESENTATION` |
| `EVT_35_TACT_001` | `SEED_FINAL_REINVENTION` | `SEED_LOW_STATS_HIGH_IMPACT` |
| `EVT_35_BENCH_001` | `SEED_FIVE_MATCHES_UNUSED` | `SEED_FINAL_ROLE_ACCEPTANCE` |
| `EVT_35_RECORD_001` | `SEED_RECORD_PASSED` | `SEED_SUCCESSOR_ALLIANCE` |
| `EVT_35_NT_001` | `SEED_EMERGENCY_NT_RETURN` | `SEED_FINAL_NT_POSTURE` / national phasedown |
| `EVT_35_JAN_001` | `SEED_LAST_JANUARY_MOVE` | `SEED_PARALLEL_NEGOTIATION` |
| `EVT_35_IMG_001` | `SEED_RETIREMENT_MARKETING` | `SEED_RETIREMENT_PUBLIC_TONE` |

None of these events may set `retirement.status = decided` merely because their content discusses a farewell, a last sponsorship or post-career work. They are context/pressure/preparation unless an explicit choice actually commits the player to retirement.

### T5.1 Batch 04C — ages 36–38: shrinking optionality

#### Age 36

- `EVT_36_BODY_001` → `SEED_COMPETITION_SELECTIVITY`; reads `SEED_MATCH_SELECTIVITY`.
- `EVT_36_CCH_001` → `SEED_YOUNGER_COACH`; reads `SEED_NEW_COACH_RESET`.
- `EVT_36_RECORD_001` → `SEED_700_MATCH_CHOICE`; reads `SEED_RECORD_VS_BODY`.
- `EVT_36_PEER_001` → `SEED_PEER_RETIREMENT_MIRROR`; reads `SEED_RETIREMENT_DISTANCE_PROFILE`.
- `EVT_36_LOWER_001` → `SEED_DROP_LEVEL_TO_PLAY`; reads `SEED_MARKET_FLOOR_FINAL`.

#### Age 37

- `EVT_37_SHORT_001` → `SEED_THREE_MONTH_CONTRACT`; reads `SEED_BOSMAN_33`.
- `EVT_37_HOME_001` → `SEED_TEN_MATCH_HOME_RETURN`; reads `SEED_FINAL_HOME_WINDOW`.
- `EVT_37_PEN_001` → `SEED_FAREWELL_PENALTY`; reads `SEED_PENALTY_HIERARCHY`.

#### Age 38+

- `EVT_38_RICH_001` → `SEED_LAST_HUGE_OFFER`; reads `SEED_LATE_RICH_OFFER`.
- `EVT_38_MARKET_001` → `SEED_MARKET_SILENCE_END`; reads `SEED_MARKET_FLOOR_FINAL`.

`EVT_38_RICH_001` currently has an exact-title technical candidate at another age (`EVT_36_RICH_001`). Do not approve it as an alias until full trigger/options/seeds comparison is complete.

`EVT_38_MARKET_001` is especially important for player agency. Market silence must surface choices (lower salary, lower level, wait, retire, contact UDV/specific club) before a no-market closure is treated as inevitable.

---

# Retirement state machine — canonical behavior

Existing product state model is `playing → decided → announced → closed`. T5.1 must preserve that monotonic model and make canonical terminal events responsible for the transitions.

## State invariants

### `playing`

- Normal career simulation is active.
- Retirement discussion/preparation events may occur.
- A farewell offer, retirement marketing, peer retirement or post-career role **does not** equal a retirement decision.
- Epilogue must be inaccessible.

### `decided`

Meaning: the player has made a firm retirement decision, but it is not yet public/fully announced.

Requirements:

- store an explicit reason / originating event / date;
- do not reinterpret earlier `SEEN_*` flags;
- next terminal narrative responsibility is `EVT_RET_ANNOUNCE_001`;
- do not close the career directly from this state under ordinary canonical flow.

### `announced`

Meaning: retirement is public but the sporting career has not necessarily ended.

Requirements:

- player may still train/play until sporting closure;
- `EVT_RET_LASTMATCH_001` becomes eligible near the final competitive window;
- no new long-horizon transfer/career arcs should be opened;
- last match is explicitly **not guaranteed**.

### `closed`

- no further career commands/world advancement may create sporting narrative;
- UI can expose epilogue;
- epilogue is generated from the final closed state and terminal memories.

## Prohibited ordinary transitions

- `playing → closed`
- `playing → announced` without an explicit announcement action
- `decided → closed` while `EVT_RET_ANNOUNCE_001` remains canonically possible
- `closed → *`
- silently rewriting a historical technical retirement event into a canonical event the player never saw

Early/emergency retirement may use specialized migration/health logic, but it must still preserve the semantic distinction between decision, public communication and sporting closure wherever possible.

---

# Terminal canonical events

## `EVT_RET_FAM_001` — La conversación en casa

Trigger: medium/high retirement distance.

Choices and state meaning:

- A. Prepare one last season → stay `playing`; create planning memory, do **not** mark decided.
- B. Retire now → transition `playing → decided`.
- C. Continue without a date → stay `playing`.
- D. Wait for offers → stay `playing`.

Creates `SEED_FINAL_FAMILY_CONVERSATION`; reads `SEED_FAMILY_ANCHOR`.

There is a technical exact-title candidate `EVT_RET_HOME_001`; treat as `not_direct_alias` until semantic review.

## `EVT_RET_BODY_001` — El cuerpo dice basta, quizá

- rehab to return → `playing`;
- operate and decide later → normally `playing`, decision deferred;
- retire → `decided`, reason health;
- rehab for health but not competition → semantically a retirement commitment; normally `decided`, reason health, unless the engine has an explicit non-competitive intermediate state.

Creates `SEED_LAST_REHAB_DECISION`; reads/creates final body-risk context.

## `EVT_RET_HIGH_001` — Retirarte después de ganar

- retire → `decided`, reason `retire_on_high`;
- continue one year / wait for offers / continue only with same club → remain `playing`.

Creates `SEED_RETIRE_ON_HIGH_CHOICE`; reads `SEED_LAST_HERO_MOMENT`.

## `EVT_RET_LOW_001` — Retirarte después de caer

- retire → `decided`, reason `retire_on_low`;
- find another club / drop level / wait for preseason → remain `playing`.

Creates `SEED_RETIRE_AFTER_LOW`; reads `SEED_DISCARDED_REBIRTH_FINAL`.

## `EVT_RET_ANNOUNCE_001` — Quién se entera primero

Trigger: firm retirement decision (`decided`).

Every valid choice transitions `decided → announced` after its outcome resolves.

Creates `SEED_RETIREMENT_ANNOUNCEMENT_PATH`; reads `SEED_CLARA_CHANNEL` and relationship/family/farewell context.

The chosen announcement path affects relationships/media/epilogue tone, not whether the player actually retired.

## `EVT_RET_LASTMATCH_001` — El último partido no está garantizado

Trigger: `announced` + final sporting window.

Creates `SEED_LAST_MATCH_SHAPE`; reads `SEED_FAREWELL_CONTROL_FINAL`.

Possible closure shapes include:

- planned meaningful last match;
- short ceremonial/conditional appearance;
- storybook decisive appearance;
- no last appearance because health/technical/context prevents it.

The event must not manufacture a cinematic appearance. A no-match closure is canonically valid.

Technical candidate `EVT_RET_LAST_001` is explicitly **not approved** as an alias by the reconciliation audit until semantic repair.

---

# No-market retirement rule

Current batch evidence shows no-market is a major retirement route. Canon requires agency before terminal closure.

Recommended invariant:

1. When an older free agent reaches low market floor, surface `EVT_38_MARKET_001` once if eligible.
2. Respect the choice:
   - lower salary;
   - lower level;
   - wait;
   - retire;
   - proactively contact home/specific club.
3. Only after the selected search strategy fails may the engine classify the eventual retirement reason as `no_market`.
4. Even a no-market retirement should normally pass through `decided → announced → closed`.
5. If no club exists at announcement time, closure shape should naturally be `no_last_match`, not a fabricated farewell fixture.

This preserves realism while avoiding the engine deciding retirement on behalf of the player before canonical options have been exhausted.

---

# Longitudinal regression tests for 34+ and retirement

1. **Age-34 priority continuity**
   `EVT_33_FIN_001` → `SEED_AGE34_PRIORITY` → `EVT_34_BRIDGE_001` → `SEED_AGE34_REALITY`.

2. **Dorsal/succession chain**
   age-30 `SEED_DORSAL_SUCCESSION` → `EVT_34_DORSAL_001` → `SEED_FINAL_DORSAL`.

3. **Mentor/successor chain**
   earlier mentor state → `EVT_34_MENTOR_001` → `SEED_SUCCESSOR_ALLIANCE` → `EVT_35_RECORD_001`.

4. **Heroic late moment to high retirement**
   `SEED_FORM_VS_PLAN` → `EVT_34_MATCH_001` → `SEED_LAST_HERO_MOMENT` → `EVT_RET_HIGH_001`.
   Choosing continue in RET_HIGH must keep status `playing`.

5. **National-team late cycle**
   `SEED_NATIONAL_PHASEDOWN` → `EVT_34_NT_001` → `SEED_FINAL_NT_POSTURE` → `EVT_34_NT_002` and/or `EVT_35_NT_001`.

6. **Load / travel / relevance chain**
   `SEED_MATCH_SELECTIVITY` → `EVT_34_LOAD_001` → `EVT_34_TRAVEL_001` → `SEED_TEAM_WINS_WITHOUT_YOU`.
   The chain may increase role compression but must not itself decide retirement.

7. **Parallel negotiation survives eight years**
   `EVT_27_AGT_002` → `SEED_PARALLEL_NEGOTIATION` → `EVT_32_BOSMAN_001` → `EVT_35_JAN_001`.

8. **Late reinvention extends career**
   earlier role-reinvention chain → `EVT_35_TACT_001` → `SEED_FINAL_REINVENTION`.
   Validate that this can reduce retirement pressure / improve market floor for some states rather than only delaying a fixed retirement age.

9. **Peer retirement is not forced retirement**
   `EVT_36_PEER_001` can modify retirement-distance/motivation but cannot set `decided` unless the user explicitly chooses a retirement action elsewhere.

10. **Drop-level branch remains playable**
    `EVT_36_LOWER_001` choice to accept lower level must continue career with valid registration/market state.

11. **Three-month contract branch**
    `EVT_37_SHORT_001` can produce a valid additional season fragment and then return to market/retirement logic without deadlock.

12. **Home closure branch**
    `EVT_37_HOME_001` can create a ten-match home return without forcing retirement; later retirement may still use a different last-match shape.

13. **Late rich offer reversal**
    `EVT_38_RICH_001` may pull a player away from near-retirement. Accepting the offer must keep `playing`; rejecting-and-retiring moves to `decided`.

14. **Market silence agency**
    `EVT_38_MARKET_001`: test all five choices. Only explicit retire or subsequent failed search may lead to no-market retirement.

15. **Family retirement transition**
    `EVT_RET_FAM_001`: only the explicit retire-now choice sets `decided`; last-season/continue/wait choices remain `playing`.

16. **Health retirement transition**
    `EVT_RET_BODY_001`: rehab branches stay playable; retirement branch uses health reason and proceeds to announcement.

17. **Announcement monotonicity**
    for every announcement choice: `decided → announced` exactly once; no RNG/read operation causes state movement.

18. **Last-match variants**
    reproduce at least: planned, short appearance, storybook/decisive, and no-last-match. All end in `closed` without deadlock.

19. **No direct epilogue from decided**
    UI must not expose epilogue until `closed`.

20. **Deterministic terminal replay**
    same seed + same decisions → identical retirement reason, announcement path, closure shape and epilogue tags.

21. **Microfeed independence through retirement**
    toggling microfeeds must not alter retirement decision/announcement/closure for same narrative decisions and seed.

22. **Save/resume at every retirement state**
    serialize/resume valid snapshots at `playing`, `decided`, `announced`, `closed`; resume must not redraw terminal RNG or duplicate events.

23. **Migration truthfulness**
    an old save containing `EVT_RET_HOME_001` or `EVT_RET_LAST_001` may preserve that historical technical event, but migration must not silently mark `SEEN_EVT_RET_FAM_001` / `SEEN_EVT_RET_LASTMATCH_001` unless the canonical scene was actually experienced.

---

# Epilogue compatibility rules

The epilogue generator should run only from `closed` and must consume terminal facts without rewriting them.

Minimum terminal facts to expose to epilogue selection:

- retirement age;
- retirement reason;
- decision origin event;
- announcement path;
- closure shape / last-match shape;
- last club and route;
- whether player was under contract/free agent;
- body/health context;
- home-return status;
- national-team final posture;
- mentor/successor state;
- record/legacy state;
- wealth/brand/business context;
- agent/self-representation state;
- family/post-career readiness;
- public myth/fan relationship.

Compatibility examples:

- `no_last_match` and a storybook-last-match tag are mutually exclusive terminal shapes.
- primary retirement reason should be singular even if career history contains both high and low periods.
- accepting `EVT_38_RICH_001` cannot immediately produce a retirement epilogue; the accepted contract must be resolved first.
- `SEED_RETIREMENT_MARKETING` is narrative/commercial context, not proof of retirement.
- `SEED_PLAYER_LIAISON_ROLE` or high post-career readiness may make a club-role epilogue compatible, but must not guarantee it if later choices contradict it.
- home-return epilogues must distinguish actually finishing at home from merely having a home-closure pull.
- announcement style can alter public/media/family epilogue texture, but cannot change sporting facts.
- last-match epilogue wording must be driven by `SEED_LAST_MATCH_SHAPE` / closure data, never by an assumption that every career gets a farewell match.

---

# Recommended execution order after existing queue

After PR #3, PR #7 and the rebased PR #5:

1. **Batch 02C** — missing age-27 scenes and seed origins.
2. **Batch 02D** — missing age-28 scenes and consequences.
3. **Batch 02E** — missing age-29 scenes.
4. **Batch 03A** — age-30 scenes / age-30 seed layer.
5. **Batch 03B** — ages 31–33, including `EVT_33_FIN_001` transition contract.
6. **Batch 04A** — age-34 foundations.
7. **Batch 04B** — age-35 prolong/reposition/prepare layer.
8. **Batch 04C** — ages 36–38 and market contraction.
9. **Batch 04D** — terminal retirement state-machine reconciliation.
10. **Batch 04E** — epilogue compatibility audit + full retirement QA.

Do not execute 04A–04E before the seeds they consume in 27–33 have been repaired. Otherwise the late-career scenes may compile but remain causally orphaned.
